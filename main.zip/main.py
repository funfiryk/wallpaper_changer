import os

os.system('pip install requests')
os.system('pip install icrawler.builtin')
os.system('pip install ctypes')
os.system('pip install schedule')

import requests, time, icrawler.builtin, ctypes, schedule
def change_wallpaper():
    path_script = os.path.dirname(os.path.abspath(__file__))
    loc = requests.get('https://ipinfo.io/').json()
    city = loc['city']
    country = loc['country'].lower()
    api_key = '2d0ef45799d87c4e7d608393ae353bf1'
    weather = requests.get('http://api.openweathermap.org/data/2.5/weather?q=' + city + ',' + country + '&APPID=' + api_key).json()['weather'][0]['main']
    minutes = time.ctime().split()[3][:-3].split(':')
    minutes = int(minutes[0]) * 60 + int(minutes[1])
    if 0 <= minutes <= 240:
        time_of_day = 'Night'
    elif 240 < minutes <= 720:
        time_of_day = 'Morning'
    elif 720 < minutes <= 1020:
        time_of_day = 'Day'
    else:
        time_of_day = 'Evening'
    request = weather + ' sky ' + time_of_day + ' wallpaper 4k'
    images = icrawler.builtin.GoogleImageCrawler(storage={'root_dir': path_script})
    images.crawl(keyword=request, max_num=1)
    path = path_script + '\\000001.jpg'
    ctypes.windll.user32.SystemParametersInfoW(20, 0, path, 0)
    time.sleep(3)
    os.remove(path)

change_wallpaper()
schedule.every().hour.do(change_wallpaper)
while True:
    schedule.run_pending()
    time.sleep(1)